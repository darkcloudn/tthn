/**
 * @license Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md.
 */

/**
 * Basic typings for the CKEditor4 elements.
 */
export namespace CKEditor4 {
	/**
	 * The CKEditor4 editor constructor.
	 */
	export interface Config {
		[ key: string ]: any;
	}

	/**
	 * The CKEditor4 editor.
	 */
	export interface Editor {
		[ key: string ]: any;
	}

	/**
	 * The CKEditor4 editor interface type.
	 * See https://ckeditor.com/docs/ckeditor4/latest/guide/dev_uitypes.html
	 * to learn more.
	 */
	export const enum EditorType {
		INLINE = 'inline',
		CLASSIC = 'classic'
	}

	/**
	 * The event object passed to CKEditor4 event callbacks.
	 *
	 * See https://ckeditor.com/docs/ckeditor4/latest/api/CKEDITOR_eventInfo.html
	 * to learn more.
	 */
	export interface EventInfo {
		readonly name: string;
		readonly editor: any;
		readonly data: {
			[ key: string ]: any;
		};
		readonly listenerData: {
			[ key: string ]: any;
		};
		readonly sender: {
			[ key: string ]: any;
		};

		cancel(): void;

		removeListener(): void;

		stop(): void;
	}
}
